## football lineup project
Its a simple college project takes x-y-z from the user and visualize the lineup in an easy and pretty way possible

### How to run
1. Clone the repository
2. Run the compiler and run the program
3. Enter the values and see the magic
### Usage
`./main
    example:
    Enter your lineup(x-y-z): 4-3-3
`